# Partner brief — RapidLEI + QVI pilot

**Project:** selfdriven.network organisational identity and delegated authority pilot (Australia)

## Objective

Obtain an LEI and qualified vLEI credentials for an eligible legal entity affiliated with selfdriven, then demonstrate portable, cryptographically verifiable organisational identity and delegated roles. Longer term, help other independent legal entities onboard and manage appropriate credentials through accredited/qualified providers.

## RapidLEI enquiries

1. Confirm an LEI can be registered for the precise legal entity (e.g., a registered Australian company limited by guarantee), whether it already has an LEI, and the required ASIC/ABR evidence.
2. Confirm LEI registration/renewal pricing and support for the initial entity.
3. Discuss a Client Agent vs Registration Agent partnership for multiple unrelated client organisations, API coverage, due diligence, branding, responsibilities and commercial terms.
4. Ask which currently **GLEIF-qualified QVI** would support vLEI issuance for an Australian organisation, and whether RapidLEI can coordinate that workflow.
5. Ask for access to test credentials, integration documentation and sandbox environments for a KERI/vLEI verifier trial.

## QVI enquiries

1. Obtain a qualified Legal Entity vLEI for the organisation and appropriate OOR/ECR credentials for representatives.
2. Confirm self-custody of KERI AIDs, wallet, witness, recovery and revocation options.
3. Confirm CESR presentation/export, holder AID proof-of-possession and allowed verification workflows.
4. Obtain qualified production trust chain information, credential renewal and revocation SLAs, pricing, sandbox support and expected onboarding steps.
5. Clarify whether authorised legal entities can issue ECR credentials themselves under the applicable framework, and the process for approval and oversight.

## What the PoC already offers

- GLEIF LEI lookup.
- Local signed delegation sandbox (not official vLEI).
- Raw CESR presentation bridge and read-only authorization status check against a separately deployed reference verifier.
- Local Node.js implementation with zero npm dependencies, published API boundaries and mock integration tests.

## Explicit limitations

This PoC is not yet affiliated with GLEIF, RapidLEI or a QVI, cannot register an LEI, cannot issue qualified vLEI credentials, and cannot establish true holder identity without additional protocol-level work.
