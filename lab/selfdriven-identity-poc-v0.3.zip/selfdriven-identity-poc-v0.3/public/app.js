'use strict';

// Plain browser JavaScript; no modules, no third-party libraries.
const el = id => document.getElementById(id);
const state = { organisations: [], delegations: [], holder: null, holderKey: null, keriChallenge: null };
const roles = [
  'Community Steward', 'Governance Delegate', 'Resource Administrator', 'Verifier'
];
function node(tag, value, className) {
  const n = document.createElement(tag);
  if (value !== undefined && value !== null) n.textContent = String(value);
  if (className) n.className = className;
  return n;
}
function clear(element) { element.replaceChildren(); }
function notice(msg, bad = false) {
  const n = el('notice'); n.hidden = false; n.className = bad ? 'notice bad' : 'notice'; n.textContent = msg;
}
function request(url, body) {
  return fetch(url, body === undefined ? {} : {
    method: 'POST', headers: { 'content-type': 'application/json' }, body: JSON.stringify(body)
  }).then(res => res.json().then(data => {
    if (!res.ok) throw new Error(data.error || `HTTP ${res.status}`);
    return data;
  }));
}
function actionButton(label, onClick, className = '') {
  const btn = node('button', label, className); btn.type = 'button'; btn.addEventListener('click', onClick); return btn;
}
function setLoading(form, loading) {
  const button = form.querySelector('button[type="submit"]');
  if (button) button.disabled = loading;
}
function recordSummary(rec) {
  const item = node('div', null, 'item');
  const left = node('div');
  left.append(node('strong', rec.name));
  left.append(node('small', `${rec.lei} · ${rec.country || 'Unknown country'} · entity: ${rec.entityStatus} · LEI: ${rec.registrationStatus}`));
  const actions = node('div', null, 'item-actions');
  const eligible = rec.entityStatus === 'ACTIVE' && rec.registrationStatus === 'ISSUED';
  if (eligible) {
    actions.append(actionButton('Add to sandbox', () => {
      request('/api/organisations', { lei: rec.lei })
        .then(() => { notice(`Added ${rec.name} as an UNVERIFIED sandbox organisation, not proof of control.`); return refresh(); })
        .catch(e => notice(e.message, true));
    }));
  } else actions.append(node('span', 'Not currently ISSUED/ACTIVE', 'pill revoked'));
  item.append(left, actions);
  return item;
}
function renderResults(records) {
  const target = el('search-results'); clear(target);
  if (!records.length) return target.append(node('p', 'No records found.', 'hint'));
  records.forEach(r => target.append(recordSummary(r)));
}
function renderOrganisations() {
  const target = el('orgs'); clear(target);
  const sel = el('org-select'); clear(sel);
  state.organisations.forEach(o => {
    const item = node('div', null, 'item');
    const left = node('div'); left.append(node('strong', o.name));
    left.append(node('small', o.lei || 'No LEI: offline sandbox sample'));
    const side = node('div', null, 'item-actions');
    side.append(node('span', 'UNVERIFIED AUTHORITY', 'pill demo'));
    item.append(left, side); target.append(item);
    const opt = node('option', o.name); opt.value = o.id; sel.append(opt);
  });
}
function renderDelegations() {
  const target = el('delegations'); clear(target);
  if (!state.delegations.length) { target.append(node('p', 'No sandbox delegations issued yet.', 'hint')); return; }
  state.delegations.slice().reverse().forEach(d => {
    const item = node('div', null, 'item');
    const left = node('div');
    left.append(node('strong', `${d.subject.name} · ${d.role}`));
    const org = state.organisations.find(o => o.id === d.orgId);
    left.append(node('small', `${org ? org.name : d.orgId} · ${d.permissions.join(', ')} · expires ${new Date(d.expiresAt).toLocaleDateString()}`));
    const actions = node('div', null, 'item-actions');
    actions.append(node('span', d.revokedAt ? 'REVOKED' : 'SANDBOX ONLY', d.revokedAt ? 'pill revoked' : 'pill demo'));
    actions.append(actionButton('Load token', () => { el('token').value = JSON.stringify(d.token, null, 2); el('token').focus(); } ,'secondary'));
    if (!d.revokedAt) actions.append(actionButton('Revoke', () => {
      if (!window.confirm('Revoke this LOCAL SANDBOX delegation?')) return;
      request('/api/delegations/revoke', { id: d.id })
        .then(() => { notice('Sandbox delegation revoked. Verify the token again to see the rejection.'); return refresh(); })
        .catch(e => notice(e.message, true));
    }, 'danger'));
    item.append(left, actions); target.append(item);
  });
}
function renderAudit(a) {
  const target = el('audit'); clear(target);
  const status = node('p', `${a.chainValid ? 'Local hash chain intact' : 'Local hash chain failed'} · ${a.entries.length} recorded events`, 'hint');
  target.append(status);
  a.entries.slice(-8).reverse().forEach(entry => {
    const i = node('div', null, 'item');
    const left = node('div');
    left.append(node('strong', entry.type));
    left.append(node('small', `${entry.time} · SHA-256 ${entry.hash.slice(0, 22)}…`));
    i.append(left); target.append(i);
  });
}
function refresh() {
  return Promise.all([
    request('/api/organisations'), request('/api/delegations'), request('/api/audit')
  ]).then(([o, d, a]) => {
    state.organisations = o.organisations;
    state.delegations = d.delegations;
    renderOrganisations(); renderDelegations(); renderAudit(a); renderAuthDelegations();
  });
}
function search(value) {
  const q = value.trim();
  if (!q) return Promise.resolve();
  const looksLikeLei = /^[A-Z0-9]{18}[0-9]{2}$/.test(q.toUpperCase());
  return request(looksLikeLei ? '/api/lei/' + encodeURIComponent(q.toUpperCase()) : '/api/lei-search?q=' + encodeURIComponent(q))
    .then(result => renderResults(looksLikeLei ? [result] : result.results));
}
el('search-form').addEventListener('submit', e => {
  e.preventDefault(); const form = e.currentTarget; setLoading(form, true);
  search(el('search').value).catch(e => notice(e.message, true)).finally(() => setLoading(form, false));
});
el('sample-lei').addEventListener('click', () => {
  el('search').value = '529900T8BM49AURSDO55';
  el('search-form').requestSubmit();
});
el('issue-form').addEventListener('submit', e => {
  e.preventDefault(); const form = e.currentTarget; setLoading(form, true);
  const data = { orgId: el('org-select').value, subjectName: el('subject-name').value,
    subjectId: el('subject-id').value, role: el('role-select').value, days: Number(el('days').value), holderId: el('holder-key-select').value || null };
  request('/api/delegations', data)
    .then(d => {
      el('token').value = JSON.stringify(d.token, null, 2);
      notice(`Sandbox delegation signed. Role: ${d.role}. Now verify its signature.`);
      return refresh();
    }).catch(e => notice(e.message, true)).finally(() => setLoading(form, false));
});
el('verify-form').addEventListener('submit', e => {
  e.preventDefault(); const form = e.currentTarget; setLoading(form, true);
  let token;
  try { token = JSON.parse(el('token').value); }
  catch (_) { notice('Paste a valid JSON sandbox token first.', true); setLoading(form, false); return; }
  request('/api/verify', { token, permission: el('permission').value })
    .then(result => {
      el('verify-result').hidden = false;
      el('verify-result').textContent = JSON.stringify(result, null, 2);
      notice(result.sandboxAccepted ? 'Sandbox checks passed — NOT a real vLEI or legal-authority verification.' : 'Sandbox token rejected: ' + result.errors.join('; '), !result.sandboxAccepted);
    }).catch(e => notice(e.message, true)).finally(() => setLoading(form, false));
});
el('refresh').addEventListener('click', () => refresh().catch(e => notice(e.message, true)));
roles.forEach(r => { const opt = node('option', r); opt.value = r; el('role-select').append(opt); });
refresh().catch(e => notice(e.message, true));

// The GLEIF KERI verifier is a SEPARATE service. These calls are inspection only.
function vleiResult(value) {
  const output = el('vlei-result');
  output.hidden = false;
  output.textContent = JSON.stringify(value, null, 2);
}
function initVlei() {
  return request('/api/vlei/configuration').then(config => {
    el('vlei-connect').textContent = config.configured ? 'LOCAL VERIFIER CONFIGURED' : 'VERIFIER NOT CONNECTED';
    el('vlei-connect').className = config.configured ? 'pill demo' : 'pill revoked';
    el('vlei-config-note').textContent = config.configured ?
      'Bridge enabled. You must independently confirm the verifier has GLEIF root-of-trust checking, permitted schemas/LEIs and revocation checks configured.' :
      'Bridge offline: start a trusted local GLEIF verifier, then run this app with VLEI_VERIFIER_URL=http://127.0.0.1:7676 (adjust to its configured port).';
    el('vlei-present-form').querySelector('button[type="submit"]').disabled = !config.configured;
    el('vlei-check-form').querySelector('button[type="submit"]').disabled = !config.configured;
  });
}
el('vlei-present-form').addEventListener('submit', e => {
  e.preventDefault(); const form = e.currentTarget; setLoading(form, true);
  const file = el('vlei-file').files[0];
  if (!file || file.size > 1024 * 1024) {
    notice('Choose a CESR file smaller than 1 MiB.', true); setLoading(form, false); return;
  }
  file.arrayBuffer().then(data => fetch('/api/vlei/presentations/' + encodeURIComponent(el('vlei-said').value.trim()), {
    method: 'PUT', headers: { 'content-type': 'application/json+cesr' }, body: data
  })).then(r => r.json().then(data => {
    if (!r.ok) throw new Error(data.error || `HTTP ${r.status}`);
    return data;
  })).then(result => {
    vleiResult(result);
    notice(result.state === 'ACCEPTED_FOR_ASYNC_PROCESSING' ?
      'Credential submitted for verification. This does NOT indicate it is valid.' :
      `Presentation not accepted (verifier HTTP ${result.httpStatus}).`, result.state !== 'ACCEPTED_FOR_ASYNC_PROCESSING');
  }).catch(e => notice(e.message, true)).finally(() => setLoading(form, false));
});
el('vlei-check-form').addEventListener('submit', e => {
  e.preventDefault(); const form = e.currentTarget; setLoading(form, true);
  request('/api/vlei/authorizations/' + encodeURIComponent(el('vlei-aid').value.trim())).then(result => {
    vleiResult(result);
    notice(`Verifier result: ${result.state}. No application permission granted.`, result.state !== 'RECOGNISED_BY_CONFIGURED_VERIFIER');
  }).catch(e => notice(e.message, true)).finally(() => setLoading(form, false));
});
initVlei().catch(e => notice(e.message, true));


// v0.3 holder challenge proof uses WebCrypto Ed25519 in this tab. The server
// never receives the private key, and these keys are NOT KERI AIDs.
function renderAuthDelegations() {
  const sel = el('auth-delegation'); clear(sel);
  state.delegations.filter(d => !d.revokedAt && state.holder && d.token.payload.holderId === state.holder.id).forEach(d => {
    const opt = node('option', d.role + ' · ' + d.subject.name); opt.value = d.id; sel.append(opt);
  });
  renderAuthPermissions();
}
function renderAuthPermissions() {
  const selected = state.delegations.find(d => d.id === el('auth-delegation').value);
  const sel = el('auth-permission'); clear(sel);
  if (!selected) return;
  selected.permissions.forEach(p => { const opt = node('option', p); opt.value = p; sel.append(opt); });
}
el('auth-delegation').addEventListener('change', renderAuthPermissions);
el('holder-create-form').addEventListener('submit', e => {
  e.preventDefault(); const form = e.currentTarget; setLoading(form, true);
  if (!window.crypto || !window.crypto.subtle) { notice('WebCrypto unavailable; use a recent browser on localhost.', true); setLoading(form, false); return; }
  let pair;
  crypto.subtle.generateKey({ name: 'Ed25519' }, false, ['sign', 'verify'])
    .then(k => { pair = k; return crypto.subtle.exportKey('jwk', k.publicKey); })
    .then(jwk => request('/api/auth/holders', { subjectId: el('holder-subject').value.trim(),
      publicJwk: { kty: 'OKP', crv: 'Ed25519', x: jwk.x } }))
    .then(holder => {
      state.holder = holder; state.holderKey = pair.privateKey;
      el('holder-key-select').replaceChildren();
      const opt = node('option', `${holder.subjectId} · browser key ${holder.id.slice(0, 12)}`);
      opt.value = holder.id; el('holder-key-select').append(opt);
      el('subject-id').value = holder.subjectId;
      el('subject-name').value ||= 'Demo member';
      el('holder-key-note').textContent = `Key active: ${holder.id}. Now issue a new delegation bound to this key. The private key remains only in this tab.`;
      notice('Local holder key created. Issue a sandbox role for this subject next.');
      renderAuthDelegations();
    }).catch(err => notice('Could not generate holder: ' + err.message, true)).finally(() => setLoading(form, false));
});
el('holder-auth-form').addEventListener('submit', e => {
  e.preventDefault(); const form = e.currentTarget; setLoading(form, true);
  if (!state.holder || !state.holderKey) { notice('Create a holder key first.', true); setLoading(form, false); return; }
  request('/api/auth/challenges', { delegationId: el('auth-delegation').value, permission: el('auth-permission').value })
    .then(challenge => crypto.subtle.sign('Ed25519', state.holderKey, new TextEncoder().encode(challenge.message))
      .then(signature => ({ challengeId: challenge.id, signature: bytesToB64url(new Uint8Array(signature)) })))
    .then(proof => request('/api/auth/responses', proof)).then(result => {
      el('holder-result').hidden = false; el('holder-result').textContent = JSON.stringify(result, null, 2);
      notice('Sandbox holder signature, delegation status and permission accepted. This is not a real vLEI or KERI identity.');
      return refresh();
    }).catch(err => notice(err.message, true)).finally(() => setLoading(form, false));
});
function bytesToB64url(bytes) {
  let data = ''; bytes.forEach(x => data += String.fromCharCode(x));
  return btoa(data).replace(/\+/g, '-').replace(/\//g, '_').replace(/=+$/, '');
}
function initKeriPilot() {
  request('/api/auth/configuration').then(info => {
    const ready = info.vleiPilot.configured && info.vleiPilot.policyConfigured;
    el('keri-state').textContent = ready ? 'EXTERNAL SERVICES CONFIGURED' : 'EXTERNAL SERVICES NOT CONFIGURED';
    el('keri-state').className = ready ? 'pill demo' : 'pill revoked';
    el('keri-start').disabled = !ready;
  }).catch(err => notice(err.message, true));
}
el('keri-start-form').addEventListener('submit', e => {
  e.preventDefault(); const form=e.currentTarget;setLoading(form,true);
  request('/api/vlei/session/challenges', { aid: el('keri-holder-aid').value.trim(),
    said: el('keri-role-said').value.trim(), permission: el('keri-permission').value.trim() })
    .then(challenge => {
      state.keriChallenge = challenge;
      el('keri-message').value = challenge.message;
      el('keri-response-area').hidden = false;
      notice('Challenge generated. Sign with the actual KERI holder wallet, then submit the proof.');
    }).catch(err => notice(err.message,true)).finally(() => setLoading(form,false));
});
el('keri-complete-form').addEventListener('submit', e => {
  e.preventDefault(); const form=e.currentTarget;setLoading(form,true);
  if (!state.keriChallenge) { notice('Generate a challenge first.',true);setLoading(form,false);return; }
  const challengeId = state.keriChallenge.id; state.keriChallenge = null;
  request('/api/vlei/session/responses', { challengeId, signature: el('keri-signature').value.trim() })
    .then(result => { el('keri-result').hidden = false;el('keri-result').textContent = JSON.stringify(result,null,2);
      notice('External verifier and holder proof adapter reported a match. Still no application authorisation granted.'); })
    .catch(err => notice(err.message,true)).finally(() => setLoading(form,false));
});
initKeriPilot();
