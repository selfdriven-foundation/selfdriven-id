'use strict';

// selfdriven organisational identity PoC — local sandbox, NOT a vLEI issuer.
// Node.js >= 20; no npm dependencies; CommonJS + Promise/.then() style.
const http = require('node:http');
const fs = require('node:fs');
const path = require('node:path');
const crypto = require('node:crypto');
const { createVerifierBridge } = require('./vlei-bridge');
const { createDemoHolderLab, createKeriPilot } = require('./holder-auth');

const DEFAULT_BASE = 'https://api.gleif.org/api/v1';
const LEI_PATTERN = /^[A-Z0-9]{18}[0-9]{2}$/;
const ROLES = Object.freeze({
  'Community Steward': ['community.read', 'community.coordinate'],
  'Governance Delegate': ['community.read', 'governance.vote', 'governance.propose'],
  'Resource Administrator': ['community.read', 'resources.manage'],
  'Verifier': ['community.read', 'credentials.verify']
});

const now = () => new Date().toISOString();
const id = () => crypto.randomUUID();
const hash = (data) => crypto.createHash('sha256').update(data).digest('hex');
const base64url = (buf) => Buffer.from(buf).toString('base64url');
function canonical(v) {
  if (Array.isArray(v)) return '[' + v.map(canonical).join(',') + ']';
  if (v && typeof v === 'object') return '{' + Object.keys(v).sort().map(k => JSON.stringify(k) + ':' + canonical(v[k])).join(',') + '}';
  return JSON.stringify(v);
}
function httpError(status, message) {
  const e = new Error(message); e.status = status; return e;
}
function asText(s, label, max = 120) {
  if (typeof s !== 'string' || !s.trim() || s.trim().length > max) throw httpError(400, `${label} must be 1–${max} characters`);
  return s.trim();
}
function keyPair() {
  const kp = crypto.generateKeyPairSync('ed25519');
  return {
    publicJwk: kp.publicKey.export({ format: 'jwk' }),
    privateJwk: kp.privateKey.export({ format: 'jwk' })
  };
}
function slimRecord(r) {
  const a = r && r.attributes || {};
  const e = a.entity || {};
  const reg = a.registration || {};
  return {
    lei: String(a.lei || r.id || '').toUpperCase(),
    name: e.legalName && e.legalName.name || '(unknown)',
    country: e.legalAddress && e.legalAddress.country || '',
    entityStatus: e.status || 'UNKNOWN',
    registrationStatus: reg.status || 'UNKNOWN',
    nextRenewal: reg.nextRenewalDate || null,
    managingLou: reg.managingLou || null,
    referenceUrl: 'https://search.gleif.org/#/record/' + encodeURIComponent(String(a.lei || r.id || '')),
    checkedAt: now()
  };
}

function createApp(opts = {}) {
  const dbFile = opts.dbFile || path.join(__dirname, 'data', 'identity-demo.json');
  const apiBase = (opts.gleifBaseUrl || DEFAULT_BASE).replace(/\/$/, '');
  const home = path.join(__dirname, 'public');
  const vlei = createVerifierBridge({ baseUrl: opts.verifierBaseUrl ?? process.env.VLEI_VERIFIER_URL });
  fs.mkdirSync(path.dirname(dbFile), { recursive: true });
  let db;
  if (fs.existsSync(dbFile)) {
    db = JSON.parse(fs.readFileSync(dbFile, 'utf8'));
  } else {
    db = { version: 3, organisations: [], delegations: [], holders: [], audit: [] };
    const kp = keyPair();
    db.organisations.push({ id: id(), name: 'Sample Community (SANDBOX)', lei: null, leiRecord: null, ...kp, createdAt: now(), sandbox: true });
    fs.writeFileSync(dbFile, JSON.stringify(db, null, 2), { mode: 0o600 });
  }
  db.holders ||= [];
  function save() {
    const tmp = dbFile + '.' + process.pid + '.tmp';
    fs.writeFileSync(tmp, JSON.stringify(db, null, 2), { mode: 0o600 });
    fs.renameSync(tmp, dbFile);
  }
  function audit(type, detail) {
    const previousHash = db.audit.length ? db.audit[db.audit.length - 1].hash : 'GENESIS';
    const data = { id: id(), time: now(), type, detail, previousHash };
    db.audit.push({ ...data, hash: hash(canonical(data)) });
    save();
  }
  function publicOrg(o) {
    return { id: o.id, name: o.name, lei: o.lei, leiRecord: o.leiRecord, publicJwk: o.publicJwk, sandbox: o.sandbox, createdAt: o.createdAt, authorityVerified: false };
  }
  function publicDelegation(d) {
    return { id: d.id, orgId: d.orgId, subject: d.token.payload.subject, role: d.token.payload.role,
      permissions: d.token.payload.permissions, issuedAt: d.token.payload.issuedAt,
      expiresAt: d.token.payload.expiresAt, revokedAt: d.revokedAt, token: d.token };
  }
  function gleifGet(url) {
    return fetch(url, { headers: { accept: 'application/vnd.api+json, application/json' }, signal: AbortSignal.timeout(9000) })
      .then(r => {
        if (r.status === 404) throw httpError(404, 'No LEI found in GLEIF');
        if (!r.ok) throw httpError(502, `GLEIF returned HTTP ${r.status}`);
        return r.json();
      })
      .catch(e => { if (e.status) throw e; throw httpError(502, 'GLEIF lookup unavailable: ' + e.message); });
  }
  function getLei(lei) {
    const normalised = asText(lei, 'LEI', 20).toUpperCase();
    if (!LEI_PATTERN.test(normalised)) throw httpError(400, 'LEI must have 20 uppercase letters/digits, ending in 2 check digits');
    return gleifGet(apiBase + '/lei-records/' + normalised).then(body => slimRecord(body.data));
  }
  function searchLei(q) {
    const term = asText(q, 'Search', 90);
    const u = new URL(apiBase + '/lei-records');
    u.searchParams.set('filter[entity.legalName]', term);
    u.searchParams.set('page[size]', '8');
    return gleifGet(u.toString()).then(body => ({ results: (body.data || []).map(slimRecord) }));
  }
  function enroll(body) {
    if (body.demo) throw httpError(400, 'Sandbox organisation is created automatically');
    const lei = asText(body.lei, 'LEI', 20).toUpperCase();
    if (db.organisations.some(o => o.lei === lei)) throw httpError(409, 'LEI is already in the sandbox');
    return getLei(lei).then(rec => {
      if (rec.registrationStatus !== 'ISSUED' || rec.entityStatus !== 'ACTIVE')
        throw httpError(409, 'Only ACTIVE entities with ISSUED registrations can be enrolled in this PoC');
      const kp = keyPair();
      const o = { id: id(), name: rec.name, lei: rec.lei, leiRecord: rec,
        ...kp, createdAt: now(), sandbox: true };
      db.organisations.push(o);
      audit('org.enrolled-demo', { orgId: o.id, lei: o.lei });
      return publicOrg(o);
    });
  }
  function issue(body) {
    const org = db.organisations.find(o => o.id === body.orgId);
    if (!org) throw httpError(404, 'Organisation not found');
    const subject = { id: asText(body.subjectId, 'Subject ID', 100), name: asText(body.subjectName, 'Subject name', 100) };
    const holder = body.holderId ? db.holders.find(h => h.id === body.holderId && h.subjectId === subject.id) : null;
    if (body.holderId && !holder) throw httpError(409, 'Holder key not registered for subject');
    const role = asText(body.role, 'Role', 60);
    if (!Object.hasOwn(ROLES, role)) throw httpError(400, 'Unknown demo role');
    const days = Number(body.days || 7);
    if (!Number.isInteger(days) || days < 1 || days > 90) throw httpError(400, 'Validity must be 1–90 days');
    const payload = {
      version: 1, demoOnly: true, id: id(), orgId: org.id, orgName: org.name,
      lei: org.lei, subject, holderId: holder ? holder.id : null, role, permissions: ROLES[role],
      issuedAt: now(), expiresAt: new Date(Date.now() + days * 86400_000).toISOString()
    };
    const signature = base64url(crypto.sign(null, Buffer.from(canonical(payload)),
      crypto.createPrivateKey({ key: org.privateJwk, format: 'jwk' })));
    const token = { format: 'selfdriven-sandbox-delegation-v1', payload, signature, publicKey: org.publicJwk };
    const d = { id: payload.id, orgId: org.id, token, revokedAt: null };
    db.delegations.push(d);
    audit('delegation.issued-demo', { orgId: org.id, delegationId: d.id, subjectId: subject.id, role });
    return publicDelegation(d);
  }
  function revoke(body) {
    const d = db.delegations.find(d => d.id === body.id);
    if (!d) throw httpError(404, 'Delegation not found');
    if (d.revokedAt) throw httpError(409, 'Already revoked');
    d.revokedAt = now();
    audit('delegation.revoked-demo', { delegationId: d.id, orgId: d.orgId });
    return publicDelegation(d);
  }
  function verify(body) {
    const token = body.token;
    const errors = [];
    const payload = token && token.payload;
    if (!token || token.format !== 'selfdriven-sandbox-delegation-v1' || !payload || !payload.demoOnly || typeof token.signature !== 'string')
      throw httpError(400, 'Not a supported selfdriven sandbox delegation token (this endpoint cannot verify a real vLEI)');
    const org = db.organisations.find(o => o.id === payload.orgId);
    if (!org) errors.push('Unrecognised organisation / issuer');
    const stored = db.delegations.find(d => d.id === payload.id);
    if (!stored) errors.push('Delegation is not in the local issuance registry');
    if (stored && stored.revokedAt) errors.push('Delegation has been revoked');
    if (typeof payload.expiresAt !== 'string' || !Number.isFinite(Date.parse(payload.expiresAt)) || Date.parse(payload.expiresAt) <= Date.now())
      errors.push('Delegation expired or missing expiry');
    let signatureValid = false;
    try {
      if (org && canonical(token.publicKey) === canonical(org.publicJwk)) {
        signatureValid = crypto.verify(null, Buffer.from(canonical(payload)),
          crypto.createPublicKey({ key: org.publicJwk, format: 'jwk' }), Buffer.from(token.signature, 'base64url'));
      }
    } catch (_) { /* invalid token/key */ }
    if (!signatureValid) errors.push('Invalid signature or issuer key does not match pinned organisation key');
    // Verify the issuance registry stores the exact original token, not merely a reused ID.
    if (stored && canonical(stored.token) !== canonical(token)) errors.push('Token differs from recorded issuance');
    const permission = typeof body.permission === 'string' ? body.permission.trim() : '';
    if (permission && (!Array.isArray(payload.permissions) || !payload.permissions.includes(permission)))
      errors.push('Requested permission is not delegated');
    return {
      type: 'SANDBOX_ONLY_NOT_VLEI', sandboxAccepted: errors.length === 0,
      signatureValid, permission: permission || null, errors,
      subject: payload.subject || null, role: payload.role || null,
      org: org ? { name: org.name, lei: org.lei, registrationStatusAtEnrolment: org.leiRecord && org.leiRecord.registrationStatus } : null,
      currentVleiVerified: false, legalAuthorityVerified: false, checkedAt: now()
    };
  }
  const demoHolder = createDemoHolderLab({ db, audit, verifyDelegation: verify });
  const keriPilot = createKeriPilot({
    policyFile: opts.pilotPolicyFile ?? process.env.VLEI_PILOT_POLICY_FILE,
    adapterBaseUrl: opts.keriProofUrl ?? process.env.VLEI_KERI_PROOF_URL, vlei
  });
  function auditSummary() {
    let previous = 'GENESIS';
    let chainValid = true;
    for (const entry of db.audit) {
      const { hash: digest, ...data } = entry;
      if (entry.previousHash !== previous || digest !== hash(canonical(data))) chainValid = false;
      previous = entry.hash;
    }
    return { chainValid, entries: db.audit };
  }
  function reply(res, status, data) {
    res.writeHead(status, { 'content-type': 'application/json; charset=utf-8', 'cache-control': 'no-store', 'x-content-type-options': 'nosniff' });
    res.end(JSON.stringify(data));
  }
  function bodyJson(req) {
    return new Promise((resolve, reject) => {
      let s = ''; let finished = false;
      req.on('data', chunk => {
        if (finished) return;
        s += chunk;
        if (s.length > 131072) { finished = true; reject(httpError(413, 'Body is too large')); }
      });
      req.on('end', () => {
        if (finished) return;
        try { resolve(JSON.parse(s || '{}')); } catch (_) { reject(httpError(400, 'Invalid JSON body')); }
      });
      req.on('error', reject);
    });
  }
  function bodyBinary(req, limit = 1024 * 1024) {
    return new Promise((resolve, reject) => {
      const parts = []; let bytes = 0; let finished = false;
      req.on('data', chunk => {
        if (finished) return;
        bytes += chunk.length;
        if (bytes > limit) { finished = true; reject(httpError(413, 'CESR data exceeds 1 MiB')); req.resume(); return; }
        parts.push(chunk);
      });
      req.on('end', () => { if (!finished) resolve(Buffer.concat(parts)); });
      req.on('error', reject);
    });
  }
  const router = (req, res) => {
    const url = new URL(req.url, 'http://localhost');
    const method = req.method;
    let task;
    try {
      if (method === 'GET' && url.pathname === '/') {
        const html = fs.readFileSync(path.join(home, 'index.html'));
        res.writeHead(200, { 'content-type': 'text/html; charset=utf-8', 'content-security-policy': "default-src 'self'; script-src 'self'; style-src 'self'; connect-src 'self'; object-src 'none'; frame-ancestors 'none'", 'x-content-type-options': 'nosniff' });
        return res.end(html);
      }
      if (method === 'GET' && url.pathname === '/app.js') {
        res.writeHead(200, { 'content-type': 'application/javascript; charset=utf-8', 'x-content-type-options': 'nosniff' });
        return res.end(fs.readFileSync(path.join(home, 'app.js')));
      }
      if (method === 'GET' && url.pathname === '/style.css') {
        res.writeHead(200, { 'content-type': 'text/css; charset=utf-8', 'x-content-type-options': 'nosniff' });
        return res.end(fs.readFileSync(path.join(home, 'style.css')));
      }
      if (method === 'GET' && url.pathname === '/api/health') task = Promise.resolve({ ok: true, mode: 'SANDBOX', version: '0.3.0' });
      else if (method === 'GET' && url.pathname === '/api/auth/configuration') task = Promise.resolve({ demo: 'LOCAL_ED25519_HOLDER_PROOF', vleiPilot: keriPilot.config() });
      else if (method === 'GET' && url.pathname === '/api/auth/holders') task = Promise.resolve({ holders: demoHolder.holders() });
      else if (method === 'POST' && url.pathname === '/api/auth/holders') task = bodyJson(req).then(demoHolder.register);
      else if (method === 'POST' && url.pathname === '/api/auth/challenges') task = bodyJson(req).then(demoHolder.challenge);
      else if (method === 'POST' && url.pathname === '/api/auth/responses') task = bodyJson(req).then(demoHolder.complete);
      else if (method === 'POST' && url.pathname === '/api/vlei/session/challenges') task = bodyJson(req).then(keriPilot.challenge);
      else if (method === 'POST' && url.pathname === '/api/vlei/session/responses') task = bodyJson(req).then(keriPilot.complete);
      else if (method === 'GET' && url.pathname === '/api/vlei/configuration') task = Promise.resolve(vlei.configuration());
      else if (method === 'GET' && url.pathname.startsWith('/api/vlei/authorizations/'))
        task = vlei.authorization(url.pathname.slice('/api/vlei/authorizations/'.length));
      else if (method === 'PUT' && url.pathname.startsWith('/api/vlei/presentations/')) {
        if (req.headers['content-type']?.split(';')[0].trim().toLowerCase() !== 'application/json+cesr')
          throw httpError(415, 'Expected content-type application/json+cesr');
        const said = url.pathname.slice('/api/vlei/presentations/'.length);
        task = bodyBinary(req).then(cesr => vlei.present(said, cesr));
      }
      else if (method === 'GET' && url.pathname === '/api/organisations') task = Promise.resolve({ organisations: db.organisations.map(publicOrg) });
      else if (method === 'GET' && url.pathname === '/api/delegations') task = Promise.resolve({ delegations: db.delegations.map(publicDelegation) });
      else if (method === 'GET' && url.pathname === '/api/audit') task = Promise.resolve(auditSummary());
      else if (method === 'GET' && url.pathname === '/api/lei-search') task = searchLei(url.searchParams.get('q'));
      else if (method === 'GET' && url.pathname.startsWith('/api/lei/')) task = getLei(url.pathname.slice('/api/lei/'.length));
      else if (method === 'POST' && url.pathname === '/api/organisations') task = bodyJson(req).then(enroll);
      else if (method === 'POST' && url.pathname === '/api/delegations') task = bodyJson(req).then(issue);
      else if (method === 'POST' && url.pathname === '/api/delegations/revoke') task = bodyJson(req).then(revoke);
      else if (method === 'POST' && url.pathname === '/api/verify') task = bodyJson(req).then(verify);
      else throw httpError(404, 'Unknown endpoint');
    } catch (e) { task = Promise.reject(e); }
    task.then(data => reply(res, 200, data))
      .catch(e => reply(res, e.status || 500, { error: e.status ? e.message : 'Internal error' }));
  };
  return http.createServer(router);
}

if (require.main === module) {
  const port = Number(process.env.PORT || 8765);
  const server = createApp();
  server.listen(port, '127.0.0.1', () => {
    console.log(`selfdriven identity sandbox: http://127.0.0.1:${port}`);
    console.log('v0.3 LOCAL DEMO ONLY — no production grants, no independent KERI verification built-in.');
  });
}
module.exports = { createApp, canonical, ROLES };
