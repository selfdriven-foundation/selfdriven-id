'use strict';
// Local-only v0.3 authentication laboratory. Two intentionally separate paths:
// 1) Sandbox Ed25519 holder proof for functional tests and offline UI.
// 2) Pilot KERI proof adapter: a separately trusted localhost service MUST actually
//    verify holder signatures against the current KERI key state. This app DOES NOT.
const fs = require('node:fs');
const crypto = require('node:crypto');
const { identifier, verifierUrl } = require('./vlei-bridge');

const b64 = value => Buffer.from(value).toString('base64url');
const digest = value => crypto.createHash('sha256').update(value).digest('hex');
const fail = (status, message) => Object.assign(new Error(message), { status });
const SCOPE = /^[a-z][a-z0-9_.:-]{2,79}$/;
const MAX_CHALLENGES = 300;
const TTL_MS = 90_000;
function stable(v) {
  if (Array.isArray(v)) return '[' + v.map(stable).join(',') + ']';
  if (v && typeof v === 'object') return '{' + Object.keys(v).sort().map(k => JSON.stringify(k) + ':' + stable(v[k])).join(',') + '}';
  return JSON.stringify(v);
}
function ensureText(value, label, max=128) {
  if (typeof value !== 'string' || !value.trim() || value.length > max) throw fail(400, `${label} required, max ${max} chars`);
  return value.trim();
}
function scope(value) {
  if (typeof value !== 'string' || !SCOPE.test(value)) throw fail(400, 'Invalid permission scope');
  return value;
}
function parsePublicKey(jwk) {
  if (!jwk || typeof jwk !== 'object' || Array.isArray(jwk) ||
    Object.keys(jwk).sort().join(',') !== 'crv,kty,x' ||
    jwk.kty !== 'OKP' || jwk.crv !== 'Ed25519' ||
    typeof jwk.x !== 'string' || !/^[a-zA-Z0-9_-]{43}$/.test(jwk.x)) throw fail(400, 'Public Ed25519 JWK (kty, crv, x only) required');
  try { return crypto.createPublicKey({ format: 'jwk', key: jwk }); }
  catch { throw fail(400, 'Invalid Ed25519 public key'); }
}
function signatureBytes(value) {
  if (typeof value !== 'string' || !/^[a-zA-Z0-9_-]{86}$/.test(value)) throw fail(400, 'Ed25519 signature must be base64url');
  const buffer = Buffer.from(value, 'base64url');
  if (buffer.length !== 64) throw fail(400, 'Invalid Ed25519 signature size');
  return buffer;
}
function challengeStore() {
  const challenges = new Map();
  function create(message) {
    const now = Date.now();
    for (const [key, entry] of challenges) if (entry.expiresMs <= now) challenges.delete(key);
    if (challenges.size >= MAX_CHALLENGES) throw fail(429, 'Too many pending challenges');
    const id = crypto.randomUUID();
    const payload = Object.freeze({ protocol: 'selfdriven-auth-poc-v0.3', audience: 'selfdriven-identity-local-only', nonce: b64(crypto.randomBytes(32)), createdAt: new Date(now).toISOString(), expiresAt: new Date(now + TTL_MS).toISOString(), ...message });
    const item = { payload, message: stable(payload), expiresMs: now + TTL_MS };
    challenges.set(id, item);
    return { id, message: item.message, expiresAt: payload.expiresAt };
  }
  function consume(id) {
    ensureText(id, 'Challenge ID', 80);
    const entry = challenges.get(id);
    // Consume on first attempt, including wrong signature: replay fails closed.
    challenges.delete(id);
    if (!entry) throw fail(401, 'Challenge unknown, expired or already used');
    if (entry.expiresMs <= Date.now()) throw fail(401, 'Challenge expired');
    return entry;
  }
  return { create, consume };
}
function createDemoHolderLab({ db, audit, verifyDelegation }) {
  db.holders ||= [];
  const challenges = challengeStore();
  function holders() {
    return db.holders.map(h => ({ id: h.id, subjectId: h.subjectId, publicJwk: h.publicJwk, kind: 'ED25519_SANDBOX_NOT_KERI' }));
  }
  function register(body) {
    const subjectId = ensureText(body.subjectId, 'Subject ID', 100);
    parsePublicKey(body.publicJwk);
    const publicJwk = { kty: 'OKP', crv: 'Ed25519', x: body.publicJwk.x };
    const id = digest(stable(publicJwk)).slice(0, 32);
    if (db.holders.some(h => h.id === id)) throw fail(409, 'Public key already registered');
    db.holders.push({ id, subjectId, publicJwk });
    audit('demo-holder.registered', { holderId: id, subjectId });
    return holders().find(h => h.id === id);
  }
  function challenge(body) {
    const d = db.delegations.find(d => d.id === body.delegationId);
    if (!d) throw fail(404, 'Delegation not found');
    const holderId = d.token.payload.holderId;
    const holder = db.holders.find(h => h.id === holderId);
    if (!holder || d.token.payload.subject.id !== holder.subjectId) throw fail(403, 'Delegation is not bound to a registered holder key');
    const permission = scope(body.permission);
    const result = verifyDelegation({ token: d.token, permission });
    if (!result.sandboxAccepted) throw fail(403, `Demo delegation invalid: ${result.errors.join('; ')}`);
    return { ...challenges.create({ mode: 'DEMO', delegationId: d.id, holderId, orgId: d.orgId, permission }), mode: 'DEMO', holderId };
  }
  function complete(body) {
    const entry = challenges.consume(body.challengeId);
    const { mode, delegationId, holderId, permission } = entry.payload;
    if (mode !== 'DEMO') throw fail(401, 'Wrong challenge kind');
    const d = db.delegations.find(d => d.id === delegationId);
    const holder = db.holders.find(h => h.id === holderId);
    if (!d || !holder || d.token.payload.holderId !== holderId || d.token.payload.subject.id !== holder.subjectId)
      throw fail(403, 'Issuer/holder binding missing');
    const checked = verifyDelegation({ token: d.token, permission });
    if (!checked.sandboxAccepted) throw fail(403, 'Delegation expired, revoked or invalid');
    const valid = crypto.verify(null, Buffer.from(entry.message), parsePublicKey(holder.publicJwk), signatureBytes(body.signature));
    if (!valid) throw fail(401, 'Holder signature invalid');
    audit('demo-holder.proved-possession', { holderId, delegationId, permission });
    return { state: 'SANDBOX_PROOF_ACCEPTED', holderAuthenticatedInSandbox: true, delegatedPermissionChecked: true,
      mode: 'ED25519_SANDBOX_NOT_KERI', permission, orgId: d.orgId, holderId,
      legalAuthorityVerified: false, vleiVerified: false, applicationAuthorizationGranted: false,
      notice: 'This proves possession of a locally registered demo key, not a verified KERI AID, identity or vLEI.' };
  }
  return { holders, register, challenge, complete };
}
function createKeriPilot({ policyFile, adapterBaseUrl, vlei }) {
  const adapter = verifierUrl(adapterBaseUrl);
  const challenges = challengeStore();
  function config() { return { kind: 'KERIA_HOLDER_SIGNATURE_ADAPTER', configured: !!adapter, policyConfigured: !!policyFile && fs.existsSync(policyFile),
    productionReady: false, enableRealApplicationAccess: false,
    required: ['QVI-issued vLEI ECR credential', 'GLEIF verifier with production root and revocation enabled', 'separate KERI signature verifier resolving current holder AID key state', 'operator-provisioned LEI/role/policy mapping'] };
  }
  function policy(aid, said, permission) {
    if (!policyFile || !fs.existsSync(policyFile)) throw fail(503, 'Pilot policy file not configured');
    let parsed;
    try { parsed = JSON.parse(fs.readFileSync(policyFile, 'utf8')); } catch { throw fail(503, 'Invalid pilot policy file'); }
    if (!parsed || parsed.mode !== 'PILOT_ONLY' || !Array.isArray(parsed.grants)) throw fail(503, 'Invalid pilot policy mode');
    const grant = parsed.grants.find(g => g.aid === aid && g.said === said && g.permission === permission &&
      typeof g.lei === 'string' && /^[A-Z0-9]{18}[0-9]{2}$/.test(g.lei) && typeof g.role === 'string' && g.role.length <= 80);
    if (!grant) throw fail(403, 'AID, SAID and permission not provisioned in local pilot policy');
    return { lei: grant.lei, role: grant.role };
  }
  function challenge(body) {
    const aid = identifier(body.aid, 'Holder AID');
    const said = identifier(body.said, 'Credential SAID');
    const permission = scope(body.permission);
    const grant = policy(aid, said, permission);
    if (!adapter) throw fail(503, 'Independent KERI signature adapter is not configured');
    return { ...challenges.create({ mode: 'VLEI_ECR_PILOT', aid, said, permission, lei: grant.lei, role: grant.role }),
      mode: 'VLEI_ECR_PILOT', aid, said, permission,
      instruction: 'Sign the exact UTF-8 message with a holder-controlled KERI AID wallet; never send private key material.' };
  }
  function complete(body) {
    const entry = challenges.consume(body.challengeId);
    if (entry.payload.mode !== 'VLEI_ECR_PILOT') throw fail(401, 'Wrong challenge kind');
    const { aid, said, lei, role, permission } = entry.payload;
    // Re-check manually provisioned pilot policy before touching external services.
    policy(aid, said, permission);
    const signature = ensureText(body.signature, 'KERI signature', 8192);
    if (!adapter) throw fail(503, 'Independent KERI adapter not configured');
    // Read only status from external GLEIF verifier; 202 alone is not verification.
    return vlei.authorization(aid).then(result => {
      if (!result.verifierRecognised || result.credentialSaid !== said)
        throw fail(403, 'GLEIF verifier did not recognise this exact holder AID + credential SAID');
      return fetch(adapter + '/verify', {
        method: 'POST', redirect: 'error', signal: AbortSignal.timeout(10000),
        headers: { 'content-type': 'application/json', accept: 'application/json' },
        body: JSON.stringify({ aid, message: entry.message, signature })
      }).catch(e => { throw fail(502, 'KERI adapter not reachable: ' + e.message); });
    }).then(response => response.text().then(text => {
      if (text.length > 8192) throw fail(502, 'KERI adapter reply too large');
      let result;
      try { result = JSON.parse(text); } catch { throw fail(502, 'Malformed KERI adapter reply'); }
      if (response.status !== 200 || !result || result.aid !== aid ||
          result.messageSha256 !== digest(entry.message) || result.valid !== true || result.keyStateVerified !== true)
        throw fail(403, 'KERI holder-key verification failed or was not attested by adapter');
      return { state: 'VLEI_ECR_PILOT_EVIDENCE_ACCEPTED', aid, said, lei, role, permission,
        verifierRecognised: true, holderSignatureReportedValidByExternalAdapter: true,
        roleSource: 'LOCAL_OPERATOR_PROVISIONED_POLICY_NOT_EXTRACTED_FROM_CREDENTIAL',
        trustConfigurationAttested: false, applicationAuthorizationGranted: false, productionReady: false,
        notice: 'External verifier and KERI proof adapter accepted the evidence; this PoC never grants production access. Verify chain/policy configuration independently.' };
    }));
  }
  return { config, challenge, complete };
}
module.exports = { createDemoHolderLab, createKeriPilot, stable, digest };
