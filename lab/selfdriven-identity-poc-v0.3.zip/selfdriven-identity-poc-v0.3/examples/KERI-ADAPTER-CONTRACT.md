# Independent KERI holder signature verification adapter — v0.3 contract

**Status: Contract/interface only. No implementation of KERI cryptographic verification is included in this project. The automated adapter uses a TEST MOCK, not a real KERI verifier.**

This adapter must run as a **separate, trusted localhost process**, backed by real KERI key-state resolution (e.g. KERIA/keripy) and the appropriate witness/watch network. The local Node.js server intentionally does not implement KERI or assert a holder's AID key state itself.

## Request

`POST /verify` JSON, sent only to `http://127.0.0.1:<port>` or equivalent loopback endpoint, no redirects:

```json
{
  "aid": "<holder KERI AID in qb64>",
  "message": "<exact UTF-8 challenge string produced by PoC>",
  "signature": "<signature bytes/encoded signed proof from holder's KERI wallet>"
}
```

The adapter MUST:

1. Parse the supplied signature in the format agreed with the holder wallet (CESR/appropriate KERI proof); do NOT assume a raw Ed25519 signature is a KERI proof.
2. Resolve the **current authenticated KERI key state** for the specified `aid`; validate key state and any required witness/receipt trust criteria. Do not trust a public key supplied by the requester.
3. Verify that the signature signs the **exact byte representation of `message`**, according to the supported KERI signing profile, including algorithm, signer, rotation state and signature threshold where applicable.
4. Return `valid:true` only on complete validation, and `keyStateVerified:true` only after checking current key state. Validate relevant delegation and key-rotation status. Implement strict timeouts and error codes.
5. Preserve trust and application separation: even a valid signature alone says nothing about the person's organisational role or permission.

## Expected response (successful cryptographic proof)

HTTP 200:

```json
{
  "aid": "<EXACT same verified holder AID>",
  "messageSha256": "<lowercase SHA-256 hex digest of exact UTF-8 message>",
  "valid": true,
  "keyStateVerified": true
}
```

All other statuses, invalid JSON, wrong AID, wrong digest, `valid:false` or missing key-state confirmation are rejected by the PoC.

The challenge contains a 256-bit random nonce, `audience`, mode, holder AID, credential SAID, permission, role, LEI, creation and expiry timestamps. It expires after 90 seconds and is single-use regardless of signature success or failure. The PoC's exact JSON canonicalisation is implemented in `holder-auth.js` (`stable()`) and the complete challenge UTF-8 string is returned to the wallet unchanged.

## IMPORTANT: Exact-trust caveats

- The adapter response is currently **trusted because it comes from the manually configured localhost process**; this does not provide tamper-resistant attestation of its own identity/configuration. Its configuration, access control, authentication, auditing, key-state retrieval and hardening remain externally required.
- The GLEIF reference verifier's `/authorizations/{aid}` checks a presented vLEI ECR; it is not the holder-signature adapter itself.
- The reference verifier's HTTP 200 result supplies only AID and credential SAID in the documented API; it does not return parsed role or LEI to this PoC. Those values come from an operator-managed *pilot allowlist*; verifying those claims against the actual signed credential, and attesting the trust settings, are required for production.
- v0.3 **never issues a session or production API token**, even if both adapters return positive results.

## Suggested integration strategy

A good v0.4 task is a separately tested KERI verification microservice exposing this API via keripy, validating the real KERI AID's current key state and signed challenge, with vLEI presentation/role extraction independently cryptographically validated. Use `signify-ts` / KERIA to produce the signed proof on the holder side. Do not use the mock in `test/holder-auth.test.js` as the production adapter.

Source references:
- https://github.com/GLEIF-IT/vlei-verifier
- https://github.com/WebOfTrust/keria
- https://github.com/WebOfTrust/signify-ts
- https://www.gleif.org/en/newsroom/blog/from-passwords-to-proof-how-the-vlei-authenticator-establishes-verifiable-organizational-roles
