'use strict';
const test = require('node:test');
const assert = require('node:assert/strict');
const fs = require('node:fs');
const os = require('node:os');
const path = require('node:path');
const http = require('node:http');
const { createApp } = require('../server');

const sampleLei = '529900T8BM49AURSDO55';
const record = { data: {
  id: sampleLei, attributes: {
    lei: sampleLei,
    entity: { legalName: { name: 'Ubisecure Oy' }, legalAddress: { country: 'FI' }, status: 'ACTIVE' },
    registration: { status: 'ISSUED', nextRenewalDate: '2027-02-01', managingLou: sampleLei }
  }
} };
const listen = server => new Promise(resolve => server.listen(0, '127.0.0.1', () => resolve(`http://127.0.0.1:${server.address().port}`)));
const close = server => new Promise(resolve => server.close(resolve));
const request = (base, route, body) => fetch(base + route, body === undefined ? {} : {
  method: 'POST', headers: { 'content-type': 'application/json' }, body: JSON.stringify(body)
}).then(r => r.json().then(j => ({ status: r.status, json: j })));

test('public GLEIF lookup and local signed role verification lifecycle', () => {
  const dir = fs.mkdtempSync(path.join(os.tmpdir(), 'selfdriven-lei-'));
  const upstream = http.createServer((req, res) => {
    res.setHeader('content-type', 'application/json');
    if (req.url.startsWith(`/api/v1/lei-records/${sampleLei}`)) res.end(JSON.stringify(record));
    else if (req.url.startsWith('/api/v1/lei-records?')) res.end(JSON.stringify({ data: [record.data] }));
    else { res.statusCode = 404; res.end('{}'); }
  });
  return listen(upstream).then(mockURL => {
    const app = createApp({ dbFile: path.join(dir, 'db.json'), gleifBaseUrl: mockURL + '/api/v1' });
    return listen(app).then(base => {
      let demo, signed;
      return request(base, '/api/health').then(({ json }) => assert.equal(json.mode, 'SANDBOX'))
        .then(() => request(base, `/api/lei/${sampleLei}`).then(({ json }) => assert.equal(json.name, 'Ubisecure Oy')))
        .then(() => request(base, '/api/lei-search?q=Ubisecure').then(({ json }) => assert.equal(json.results[0].lei, sampleLei)))
        .then(() => request(base, '/api/organisations').then(({ json }) => {
          assert.equal(json.organisations.length, 1);
          demo = json.organisations[0];
          assert.equal(Object.hasOwn(demo, 'privateJwk'), false);
        }))
        .then(() => request(base, '/api/organisations', { lei: sampleLei }).then(({ status, json }) => {
          assert.equal(status, 200); assert.equal(json.lei, sampleLei);
          assert.equal(json.authorityVerified, false);
        }))
        .then(() => request(base, '/api/delegations', {
          orgId: demo.id, subjectName: 'Test participant', subjectId: 'participant-001', role: 'Governance Delegate', days: 7
        }).then(({ status, json }) => { assert.equal(status, 200); signed = json; }))
        .then(() => request(base, '/api/verify', { token: signed.token, permission: 'governance.vote' }).then(({ json }) => {
          assert.equal(json.sandboxAccepted, true);
          assert.equal(json.signatureValid, true);
          assert.equal(json.legalAuthorityVerified, false);
          assert.equal(json.currentVleiVerified, false);
        }))
        .then(() => request(base, '/api/verify', { token: signed.token, permission: 'resources.manage' }).then(({ json }) => {
          assert.equal(json.sandboxAccepted, false);
        }))
        .then(() => {
          const tampered = structuredClone(signed.token);
          tampered.payload.subject.name = 'Imposter';
          return request(base, '/api/verify', { token: tampered }).then(({ json }) => {
            assert.equal(json.sandboxAccepted, false);
            assert.equal(json.signatureValid, false);
          });
        })
        .then(() => request(base, '/api/delegations/revoke', { id: signed.id }).then(({ status }) => assert.equal(status, 200)))
        .then(() => request(base, '/api/verify', { token: signed.token }).then(({ json }) => {
          assert.equal(json.signatureValid, true);
          assert.equal(json.sandboxAccepted, false);
          assert(json.errors.some(x => x.includes('revoked')));
        }))
        .then(() => request(base, '/api/audit').then(({ json }) => {
          assert.equal(json.chainValid, true);
          assert.equal(json.entries.length, 3);
        }))
        .finally(() => close(app));
    }).finally(() => close(upstream));
  }).finally(() => fs.rmSync(dir, { recursive: true, force: true }));
});
