'use strict';
const test = require('node:test');
const assert = require('node:assert/strict');
const fs = require('node:fs');
const os = require('node:os');
const path = require('node:path');
const http = require('node:http');
const { createApp } = require('../server');
const { verifierUrl } = require('../vlei-bridge');
const aid = 'E' + 'a'.repeat(43);
const said = 'E' + 'b'.repeat(43);
const listen = server => new Promise(resolve => server.listen(0, '127.0.0.1', () => resolve('http://127.0.0.1:' + server.address().port)));
const close = server => new Promise(resolve => server.close(resolve));
const get = (base, route, options) => fetch(base + route, options).then(r => r.json().then(json => ({ http: r.status, json })));

test('config rejects arbitrary external verifier URLs', () => {
  assert.throws(() => verifierUrl('https://bad.example/'));
  assert.throws(() => verifierUrl('http://127.0.0.1:1234/somepath'));
  assert.throws(() => verifierUrl('http://localhost:1234@evil.example'));
  assert.equal(verifierUrl('http://127.0.0.1:7676'), 'http://127.0.0.1:7676');
});
test('bridge fails closed if verifier not configured', () => {
  const dir = fs.mkdtempSync(path.join(os.tmpdir(), 'selfdriven-bridge-off-'));
  const app = createApp({ dbFile: path.join(dir, 'db.json'), verifierBaseUrl: '' });
  return listen(app).then(base => get(base, '/api/vlei/configuration').then(({ json }) => {
    assert.equal(json.configured, false);
  }).then(() => get(base, '/api/vlei/authorizations/' + aid)).then(({ http }) => {
    assert.equal(http, 503);
  })).finally(() => close(app)).finally(() => fs.rmSync(dir, { recursive: true, force: true }));
});
test('bridge faithfully forwards raw CESR and treats 202, 404, 401, mismatches as non-grants', () => {
  const dir = fs.mkdtempSync(path.join(os.tmpdir(), 'selfdriven-bridge-'));
  const bytes = Buffer.from([0x7b, 0x22, 0x64, 0x22, 0x3a, 0x22, 0x45, 0xff, 0x00]);
  let captured = null;
  let mode = 'pending';
  const upstream = http.createServer((req, res) => {
    if (req.method === 'PUT') {
      const chunks = [];
      req.on('data', c => chunks.push(c));
      req.on('end', () => {
        captured = { url: req.url, contentType: req.headers['content-type'], data: Buffer.concat(chunks) };
        res.statusCode = 202; res.end('');
      });
    } else {
      if (mode === 'pending') { res.statusCode = 404; res.end(); return; }
      if (mode === 'rejected') { res.statusCode = 401; res.end(); return; }
      res.setHeader('content-type', 'application/json');
      if (mode === 'mismatch') res.end(JSON.stringify({ aid: 'E' + 'x'.repeat(43), said }));
      else if (mode === 'malformed') res.end(JSON.stringify({ authorized: true }));
      else res.end(JSON.stringify({ aid, said }));
    }
  });
  return listen(upstream).then(verifierBaseUrl => {
    const app = createApp({ dbFile: path.join(dir, 'db.json'), verifierBaseUrl });
    return listen(app).then(base => get(base, '/api/vlei/configuration').then(({ json }) => {
      assert.equal(json.configured, true);
      assert.equal(json.trustConfigurationAttested, false);
    }).then(() => get(base, '/api/vlei/presentations/' + said, {
      method: 'PUT', headers: { 'content-type': 'application/json+cesr' }, body: bytes
    })).then(({ http, json }) => {
      assert.equal(http, 200);
      assert.equal(json.state, 'ACCEPTED_FOR_ASYNC_PROCESSING');
      assert.equal(json.credentialVerified, false);
      assert.equal(json.applicationAuthorizationGranted, false);
      assert.equal(captured.url, '/presentations/' + said);
      assert.equal(captured.contentType, 'application/json+cesr');
      assert.deepEqual(captured.data, bytes);
    }).then(() => get(base, '/api/vlei/authorizations/' + aid)).then(({ json }) => {
      assert.equal(json.state, 'NOT_FOUND_OR_PENDING');
      mode = 'rejected';
    }).then(() => get(base, '/api/vlei/authorizations/' + aid)).then(({ json }) => {
      assert.equal(json.state, 'REJECTED_BY_VERIFIER');
      mode = 'mismatch';
    }).then(() => get(base, '/api/vlei/authorizations/' + aid)).then(({ json }) => {
      assert.equal(json.state, 'UNEXPECTED_RESPONSE');
      assert.equal(json.verifierRecognised, false);
      mode = 'malformed';
    }).then(() => get(base, '/api/vlei/authorizations/' + aid)).then(({ json }) => {
      assert.equal(json.state, 'UNEXPECTED_RESPONSE');
      mode = 'valid';
    }).then(() => get(base, '/api/vlei/authorizations/' + aid)).then(({ json }) => {
      assert.equal(json.state, 'RECOGNISED_BY_CONFIGURED_VERIFIER');
      assert.equal(json.verifierRecognised, true);
      assert.equal(json.applicationAuthorizationGranted, false);
      assert.equal(json.holderAuthenticated, false);
    }).then(() => get(base, '/api/vlei/presentations/' + said, {
      method: 'PUT', headers: { 'content-type': 'application/json' }, body: bytes
    })).then(({ http }) => assert.equal(http, 415))
    .then(() => get(base, '/api/vlei/authorizations/not-a-valid-aid')).then(({ http }) => assert.equal(http, 400))
    .finally(() => close(app)));
  }).finally(() => close(upstream)).finally(() => fs.rmSync(dir, { recursive: true, force: true }));
});
