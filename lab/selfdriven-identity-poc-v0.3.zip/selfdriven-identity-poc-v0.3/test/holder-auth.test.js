'use strict';
const test = require('node:test');
const assert = require('node:assert/strict');
const fs = require('node:fs');
const path = require('node:path');
const os = require('node:os');
const http = require('node:http');
const crypto = require('node:crypto');
const { createApp } = require('../server');
const { digest } = require('../holder-auth');

const listen = srv => new Promise(resolve => srv.listen(0, '127.0.0.1', () => resolve('http://127.0.0.1:' + srv.address().port)));
const close = srv => new Promise(resolve => srv.close(resolve));
const get = (base, path, body) => fetch(base + path, body === undefined ? {} : {
  method: 'POST', headers: {'content-type': 'application/json'}, body: JSON.stringify(body)
}).then(r => r.json().then(json => ({ status: r.status, json })));
const keyPair = () => crypto.generateKeyPairSync('ed25519');
const sign = (privateKey, text) => crypto.sign(null, Buffer.from(text), privateKey).toString('base64url');

test('v0.3 Ed25519 sandbox challenge: positive, bad signature, action policy, replay, revocation', () => {
  const dir = fs.mkdtempSync(path.join(os.tmpdir(), 'selfdriven-holder-'));
  const app = createApp({ dbFile: path.join(dir, 'db.json') });
  const alice = keyPair(); const bob = keyPair();
  let base, orgId, holderId, delegation;
  return listen(app).then(url => { base = url; return get(base, '/api/organisations'); })
    .then(({json}) => { orgId = json.organisations[0].id;
      return get(base, '/api/auth/holders', {subjectId: 'alice', publicJwk: alice.publicKey.export({format:'jwk'})});
    }).then(({status,json}) => { assert.equal(status,200); assert.equal(json.subjectId,'alice'); holderId = json.id;
      return get(base,'/api/auth/holders', {subjectId:'bad', publicJwk: alice.privateKey.export({format:'jwk'})});
    }).then(({status}) => { assert.equal(status,400);
      return get(base, '/api/delegations', {orgId, holderId, subjectId:'bob', subjectName:'Bob', role:'Governance Delegate'});
    }).then(({status}) => { assert.equal(status,409);
      return get(base, '/api/delegations', {orgId, holderId, subjectId:'alice', subjectName:'Alice', role:'Governance Delegate'});
    }).then(({status,json}) => { assert.equal(status,200); delegation = json; assert.equal(json.token.payload.holderId,holderId);
      return get(base,'/api/auth/challenges',{delegationId:delegation.id,permission:'resources.manage'});
    }).then(({status}) => { assert.equal(status,403);
      return get(base,'/api/auth/challenges',{delegationId:delegation.id,permission:'governance.vote'});
    }).then(({status,json}) => { assert.equal(status,200); assert.equal(json.mode,'DEMO');
      return get(base,'/api/auth/responses',{challengeId:json.id,signature:sign(bob.privateKey,json.message)})
        .then(response => ({challenge:json,response}));
    }).then(({challenge,response}) => { assert.equal(response.status,401);
      return get(base,'/api/auth/responses',{challengeId:challenge.id,signature:sign(alice.privateKey,challenge.message)});
    }).then(({status}) => { assert.equal(status,401); // one attempt consumed
      return get(base,'/api/auth/challenges',{delegationId:delegation.id,permission:'governance.vote'});
    }).then(({json}) => {
      const signature = sign(alice.privateKey,json.message);
      return get(base,'/api/auth/responses',{challengeId:json.id,signature}).then(r => ({challenge:json,result:r}));
    }).then(({challenge,result}) => { assert.equal(result.status,200); assert.equal(result.json.state,'SANDBOX_PROOF_ACCEPTED');
      assert.equal(result.json.vleiVerified,false);
      assert.equal(result.json.applicationAuthorizationGranted,false);
      return get(base,'/api/auth/responses',{challengeId:challenge.id,signature:sign(alice.privateKey,challenge.message)});
    }).then(({status}) => { assert.equal(status,401);
      return get(base,'/api/auth/challenges',{delegationId:delegation.id,permission:'governance.vote'});
    }).then(({json}) => {
      return get(base,'/api/delegations/revoke',{id:delegation.id}).then(() =>
        get(base,'/api/auth/responses',{challengeId:json.id,signature:sign(alice.privateKey,json.message)}));
    }).then(({status}) => { assert.equal(status,403);
      return get(base,'/api/auth/challenges',{delegationId:delegation.id,permission:'governance.vote'});
    }).then(({status}) => { assert.equal(status,403);
      return get(base,'/api/audit');
    }).then(({json}) => { assert.equal(json.chainValid,true); assert(json.entries.some(e => e.type === 'demo-holder.proved-possession')); })
    .finally(() => close(app)).finally(() => fs.rmSync(dir,{recursive:true,force:true}));
});

test('v0.3 external vLEI/KERI pilot: exact AID/SAID, policy, proof, fail-closed mismatches, no app grant', () => {
  const dir = fs.mkdtempSync(path.join(os.tmpdir(), 'selfdriven-keri-pilot-'));
  const aid='E'+'a'.repeat(43); const said='E'+'s'.repeat(43); const other='E'+'b'.repeat(43);
  const wallet=keyPair();
  const policyFile=path.join(dir,'policy.json');
  fs.writeFileSync(policyFile, JSON.stringify({mode:'PILOT_ONLY',grants:[{aid,said,lei:'529900T8BM49AURSDO55',role:'Governance Delegate',permission:'governance.vote'}]}));
  let statusMode='valid', useWrongDigest=false;
  const verifier=http.createServer((req,res) => {
    res.setHeader('content-type','application/json');
    if (statusMode==='pending') {res.statusCode=404;res.end('{}');return;}
    res.end(JSON.stringify({aid,said:statusMode==='wrongSaid'?other:said}));
  });
  const adapter=http.createServer((req,res) => {
    const chunks=[];req.on('data',c=>chunks.push(c));req.on('end',()=>{
      const body=JSON.parse(Buffer.concat(chunks).toString('utf8'));
      const valid=crypto.verify(null,Buffer.from(body.message),wallet.publicKey,Buffer.from(body.signature,'base64url'));
      res.setHeader('content-type','application/json');
      res.end(JSON.stringify({aid:body.aid,messageSha256:useWrongDigest?'wrong':digest(body.message),valid,keyStateVerified:true}));
    });
  });
  let app, base;
  return Promise.all([listen(verifier),listen(adapter)]).then(([verifierBaseUrl,keriProofUrl]) => {
    app=createApp({dbFile:path.join(dir,'db.json'),verifierBaseUrl,keriProofUrl,pilotPolicyFile:policyFile});
    return listen(app);
  }).then(url => {base=url;return get(base,'/api/auth/configuration');})
    .then(({json}) => {assert.equal(json.vleiPilot.configured,true);assert.equal(json.vleiPilot.policyConfigured,true);
      return get(base,'/api/vlei/session/challenges',{aid,said,permission:'resources.manage'});
    }).then(({status}) => {assert.equal(status,403);
      return get(base,'/api/vlei/session/challenges',{aid,said,permission:'governance.vote'});
    }).then(({status,json}) => {assert.equal(status,200);
      const signature=sign(wallet.privateKey,json.message);
      statusMode='wrongSaid';
      return get(base,'/api/vlei/session/responses',{challengeId:json.id,signature});
    }).then(({status}) => {assert.equal(status,403);
      statusMode='pending';
      return get(base,'/api/vlei/session/challenges',{aid,said,permission:'governance.vote'});
    }).then(({json}) => get(base,'/api/vlei/session/responses',{challengeId:json.id,signature:sign(wallet.privateKey,json.message)}))
    .then(({status}) => {assert.equal(status,403);
      statusMode='valid';
      return get(base,'/api/vlei/session/challenges',{aid,said,permission:'governance.vote'});
    }).then(({json}) => {
      useWrongDigest=true;
      return get(base,'/api/vlei/session/responses',{challengeId:json.id,signature:sign(wallet.privateKey,json.message)});
    }).then(({status}) => {assert.equal(status,403);
      useWrongDigest=false;
      return get(base,'/api/vlei/session/challenges',{aid,said,permission:'governance.vote'});
    }).then(({json}) => {
      const signature=sign(wallet.privateKey,json.message);
      return get(base,'/api/vlei/session/responses',{challengeId:json.id,signature})
        .then(result => ({result,challenge:json}));
    }).then(({result,challenge}) => {assert.equal(result.status,200); assert.equal(result.json.state,'VLEI_ECR_PILOT_EVIDENCE_ACCEPTED');
      assert.equal(result.json.applicationAuthorizationGranted,false);
      assert.equal(result.json.trustConfigurationAttested,false);
      return get(base,'/api/vlei/session/responses',{challengeId:challenge.id,signature:sign(wallet.privateKey,challenge.message)});
    }).then(({status}) => {assert.equal(status,401);})
    .finally(() => close(app)).finally(() => Promise.all([close(verifier),close(adapter)])).finally(() => fs.rmSync(dir,{recursive:true,force:true}));
});
