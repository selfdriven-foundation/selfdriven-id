# selfdriven.network — Identity PoC roadmap (as of v0.3)

## Completed in v0.1
- GLEIF public LEI lookup and sandbox organisations.
- Non-GLEIF Ed25519 sandbox delegation, local role/permission verification, expiry, revocation, audit hash chain.

## Completed in v0.2
- GLEIF reference verifier integration bridge for raw CESR credential submission and AID-status checks.
- Conservative validation of expected external response; async `202` remains pending and never signals verified credentials.
- Localhost-only verifier connectivity and explicit GLEIF root/revocation configuration guidance.

## Completed in v0.3 (six passing automated tests)
- Browser-side WebCrypto Ed25519 non-exportable private key, local public-key registration and holder-to-delegation binding.
- Cryptographic 90-second one-use holder challenge + response, replay defence, action scope and revocation rechecks.
- Functional UI for a two-key demonstration: demo organisation issuer vs holder-controlled browser key.
- Configured-only KERI holder proof adapter contract (separate local process), conservative response verification.
- PILOT_ONLY operator-pinned exact AID/SAID/LEI/role/scope policy and external verifier + proof orchestration; no access grant.
- Automated integration tests with mock GLEIF and mock KERI services for success/denial/bad signature/replay/revocation/mismatch.

## v0.4 — first genuine vLEI pilot (external dependencies)
- Register LEI for eligible selfdriven legal entity (or use an existing registered one).
- Obtain actual Legal Entity and ECR credentials from a GLEIF Qualified vLEI Issuer (e.g. engage RapidLEI for LEI + partner integration and a QVI for vLEI).
- Run the real GLEIF verifier and KERIA/Signify/witness ecosystem in an isolated environment; verify root trust, key state, status and revocation.
- Implement the separately deployed KERI holder proof adapter (not included in v0.3) and test real wallet-produced signatures using KERI's authentic proof format.
- Parse LEI/role directly from verified ACDC instead of only an operator-managed allowlist; cross-check issuer and governing chain.
- Obtain a live demonstration with real QVI-issued ECR credential and document a reproducible cryptographic audit trace.

## v0.5 — organisational onboarding and authorisation
- Passkey-authenticated administrative account and approval workflow; KERI holder proof for each requested scope.
- Explicit ABAC policy with organisation, person, role, action, resource, temporal limits, tenant and fresh revocation.
- Separate data plane, control plane, issuer, wallet, verifier and audit log. Use a proper secrets store/KMS and independently anchored audit receipts.
- Organisation self-service onboarding with LEI verification, proof of authority and QVI partnership (do not confuse onboarding with QVI issuance).

## Production acceptance gates
- Independent trust-root verification and signature-chain verification of legal entity/QVI/ECR credentials.
- Real holder key control verified against latest KERI state and signed challenge, including rotations and compromised-key handling.
- Legal role and delegated scope proven, not self-asserted; revocations timely, verified and fail-closed.
- Strong admin authentication, high-assurance authorisation, tenant isolation, security reviews, Australian privacy and governance/legal assessments.
- Secure key custody/recovery, rate limiting, logs, secrets management, monitoring, safe deployments, external audit.
