# selfdriven.network — Organisation Identity PoC v0.3

**Executable, local-only organisational identity demonstration (Node.js >=20, CommonJS, browser UI).**

> **This is NOT a GLEIF-qualified vLEI issuer, a live KERI wallet, a qualified credential verifier, or a production authorisation system.** It demonstrates local holder possession and an integration seam for independent KERI and vLEI verifiers. The integration unit tests mock those third-party services. No genuine QVI-issued vLEI has been tested end-to-end.

## Quick start

```bash
unzip selfdriven-identity-poc-v0.3.zip
cd selfdriven-identity-poc-v0.3
npm start
```

Open **http://127.0.0.1:8765** on the same Mac/PC. Requires a recent browser supporting WebCrypto Ed25519 and secure-context `localhost`. No `npm install` or external npm packages required. `npm test` runs the automated suite.

When upgrading from v0.2, use this extracted v0.3 folder. The new version starts with its own demo database unless you intentionally copy your existing `data/identity-demo.json` (NOT RECOMMENDED if it contains any real data). `data/` holds an unencrypted local demo organisational signing key and event log. Do not commit those files.

## Local v0.3 happy path (no LEI or QVI needed)

1. In **3B. Holder proof**, enter subject ID `participant-001`; select **Create holder key**. Your browser generates a **non-extractable Ed25519 private key**, retained only in this tab; only the public JWK is sent to the server.
2. In **3. Delegate a role**, the holder selector and subject ID are pre-filled. Select **Governance Delegate**, then **Issue sandbox delegation** for the sample community.
3. Back in **3B**, select the new delegation and `governance.vote`; select **Sign challenge and test permission**. Browser signs the one-time message; the Node server verifies the signature, checks exact key/holder binding, and rechecks the delegation's signature, expiry, registry status, revocation and permission.
4. In **4. Delegations**, revoke the delegation. Repeat the signed challenge: it must now reject access. Refreshing the tab discards the browser private key; creating a new holder key and delegation is necessary.
5. Run `npm test` to see additional test coverage for wrong signer, failed/replayed challenges, mismatched scope, failed LEI/SAID match and malformed external responses.

**Demo limitations:** anyone on the computer with access to this local service can register a key, add LEIs and issue demo delegations. The demo holder's name and public key were not verified by a QVI, and its Ed25519 key is not a KERI AID. `SANDBOX_PROOF_ACCEPTED` means only that the cryptographic local demonstration succeeded. `applicationAuthorizationGranted` is **always false**.

## Preserved v0.1 / v0.2 functionality

- Public official GLEIF LEI search/lookup; can add an ACTIVE/ISSUED LEI to local unverified organisation registry.
- Locally signed Ed25519 **sandbox** delegation, role/permission verification, expiry and revocation, limited tamper-evident audit chain.
- External [GLEIF vlei-verifier](https://github.com/GLEIF-IT/vlei-verifier) bridge for raw `application/json+cesr` credential submission to `PUT /presentations/{said}` and for `GET /authorizations/{aid}` status inspection.
- Requires `VERIFY_ROOT_OF_TRUST=True` **in the external verifier**, plus `revocationCheck=true`, appropriate `trustedLeis`, `allowedSchemas`, configured GLEIF root, correct OOBIs, and a genuine ECR credential. The default GLEIF verifier does **not** verify its root of trust automatically.

To use that external service:

```bash
VLEI_VERIFIER_URL=http://127.0.0.1:7676 npm start
```

Use the actual verifier's port; `7676` is an example only. The PoC prohibits non-local verifier connections and redirects. HTTP 202 means queued, NOT verified. HTTP 200 and correct AID/SAID from the verifier's `/authorizations/{aid}` is an independently reported status, not proof the current person controls that AID or has a permission in this app.

## v0.3 genuine KERI pilot integration (EXTERNAL DEPENDENCIES REQUIRED)

The browser **5B. vLEI holder-session pilot** has a challenge flow that will **not enable** until configured with both a local pilot policy and a local KERI key-state/signature adapter. The test suite's adapter is a mock; no real KERI adapter is shipped.

Requirements:

1. Obtain an LEI for the actual registered legal entity, then Legal Entity + necessary ECR credential(s) from a current qualified vLEI issuer.
2. Independently deploy and configure GLEIF's reference verifier; validate root-of-trust, status, schema, trusted LEIs and its ability to verify the **exact genuine AID + ECR SAID**.
3. Independently deploy a **KERI holder proof service** capable of validating holder-signed challenges against their latest KERI key state. See [examples/KERI-ADAPTER-CONTRACT.md](examples/KERI-ADAPTER-CONTRACT.md). Signify/KERIA can be used in the holder wallet integration.
4. After an authorised operator has checked the genuine signed credential, copy [examples/pilot-policy.example.json](examples/pilot-policy.example.json) to a local private location (e.g. `./data/pilot-policy.json`) and replace placeholder AID, SAID and LEI with genuine matched values; configure an explicit role and allowed permission. **This is a manually provisioned, un-attested pilot policy.** The verifier's documented status API does not supply signed role/LEI claims to this app.
5. Start:

```bash
VLEI_VERIFIER_URL=http://127.0.0.1:7676 \\
VLEI_KERI_PROOF_URL=http://127.0.0.1:8787 \\
VLEI_PILOT_POLICY_FILE=./data/pilot-policy.json \\
node server.js
```

Enter real AID, ECR credential SAID and required scope in panel 5B. Generate a one-time challenge and sign **exactly the returned UTF-8 challenge text** using a real holder-controlled KERI AID wallet. Submit the encoded KERI signature produced by the wallet. The PoC will:

- Match (AID, credential SAID, permission) against the **operator-provisioned** local policy; never accept user-provided role/LEI as verified claims.
- Recheck the external verifier's authorisation result for that exact AID **and** SAID.
- Forward the challenge message and signature to the local KERI proof adapter; require attestation of the identical AID, SHA-256 message hash, signature validity and current key state.
- Expire challenges after 90 seconds and consume every challenge on the first attempt.
- Return `VLEI_ECR_PILOT_EVIDENCE_ACCEPTED` only when all configured integrations approve; **still grant no production permission or token**. Root-of-trust configuration is not independently attested by this PoC.

**No real KERI end-to-end verification has been run by this package.** Don't expose this web server on a public network or adapt its locally unrestricted demo endpoints into production.

## API routes (added in v0.3)

| Method | Route | Function |
|---|---|---|
| GET | `/api/auth/configuration` | Demo/pilot configuration status |
| GET | `/api/auth/holders` | List local demo public keys only |
| POST | `/api/auth/holders` | Register demo holder public JWK and subject ID |
| POST | `/api/auth/challenges` | Request one-time local demo challenge |
| POST | `/api/auth/responses` | Verify holder-signed demo challenge, current delegation and action |
| POST | `/api/vlei/session/challenges` | Require policy and independent holder verifier, issue a KERI-bound pilot challenge |
| POST | `/api/vlei/session/responses` | Match externally reported vLEI status, KERI proof and operator policy; **no grant** |

For preserved v0.2 API see [ROADMAP.md](ROADMAP.md) and server source.

## Security and development gates

- Sandbox issuer signing keys are unencrypted in a local demo JSON file. Do not use them for real organisational roles.
- No login, no operator access control, no tenant isolation, no KMS/HSM, no production audit anchoring, no rate limiting, no cross-origin integration hardening. Strict loopback-only binding limits local exposure but does not make this safe for multi-user deployment.
- The KERI adapter's `valid:true` is only as trustworthy as the independently deployed adapter. The Node process does not verify KERI signatures or inspect KERI key events itself.
- The GLEIF verifier's documented API reports AID and SAID, not enough to prove signed LEI/role attributes here; the pilot uses a manually pinned policy. A v0.4 production-style integration needs cryptographic ECR claim extraction, provider trust attestations and real authorisation enforcement.
- Review the current [GLEIF vLEI governance requirements](https://www.gleif.org/en/organizational-identity/become-a-vlei-issuer-qvi/vlei-ecosystem-governance-framework) and Qualified vLEI Issuer terms before offering credential issuance to others.

## Reference sources

- GLEIF reference verifier: https://github.com/GLEIF-IT/vlei-verifier
- KERIA: https://github.com/WebOfTrust/keria
- signify-ts: https://github.com/WebOfTrust/signify-ts
- GLEIF vLEI Authenticator walk-through: https://www.gleif.org/en/newsroom/blog/from-passwords-to-proof-how-the-vlei-authenticator-establishes-verifiable-organizational-roles
