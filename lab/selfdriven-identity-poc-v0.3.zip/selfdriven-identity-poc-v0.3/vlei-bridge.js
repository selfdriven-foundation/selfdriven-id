'use strict';
// Compatibility bridge for the GLEIF-IT/vlei-verifier service.
// This application does not inspect ACDCs, authenticate AID holders, or issue vLEIs.
// The independently configured verifier makes the cryptographic/status decisions.
const IDENTIFIER = /^[A-Za-z0-9_-]{32,128}$/;
const MAX_CESR = 1024 * 1024;

function fail(status, message) {
  const error = new Error(message);
  error.status = status;
  return error;
}
function identifier(text, name) {
  if (typeof text !== 'string' || !IDENTIFIER.test(text)) {
    throw fail(400, `${name} must be a KERI-style qb64 identifier (32–128 URL-safe characters)`);
  }
  return text;
}
function verifierUrl(value) {
  if (!value) return null;
  let parsed;
  try { parsed = new URL(value); } catch (_) { throw new Error('VLEI_VERIFIER_URL is invalid'); }
  // Initial PoC refuses external services and redirects; a local verifier must be configured explicitly.
  if (parsed.protocol !== 'http:' || !['localhost', '127.0.0.1', '[::1]'].includes(parsed.hostname) ||
      parsed.username || parsed.password || parsed.search || parsed.hash || parsed.pathname !== '/') {
    throw new Error('VLEI_VERIFIER_URL must be an HTTP loopback URL with no path (e.g., http://127.0.0.1:7676/)');
  }
  return parsed.origin;
}
function createVerifierBridge(options = {}) {
  const base = verifierUrl(options.baseUrl);
  const fetchFn = options.fetchImpl || fetch;
  function configuration() {
    return { configured: !!base, kind: 'GLEIF_REFERENCE_VERIFIER_BRIDGE',
      endpointLocation: base ? 'loopback' : null,
      trustConfigurationAttested: false, // GLEIF root-of-trust and revocation are verified ONLY by external service.
      holderAuthenticated: false, applicationAuthorizationGranted: false,
      requiredVerifierSettings: ['VERIFY_ROOT_OF_TRUST=True', 'revocationCheck=true',
        'trustedLeis and allowedSchemas explicitly configured'] };
  }
  function call(path, init = {}) {
    if (!base) return Promise.reject(fail(503, 'Verifier not configured. Set VLEI_VERIFIER_URL to a trusted local GLEIF verifier.'));
    return fetchFn(base + path, { ...init, redirect: 'error', signal: AbortSignal.timeout(10000) })
      .catch(e => { throw fail(502, 'Could not reach local verifier: ' + e.message); });
  }
  function present(said, cesr) {
    identifier(said, 'Credential SAID');
    if (!Buffer.isBuffer(cesr) || !cesr.length || cesr.length > MAX_CESR) {
      throw fail(400, `CESR byte stream must be 1–${MAX_CESR} bytes`);
    }
    return call('/presentations/' + encodeURIComponent(said), {
      method: 'PUT', headers: { 'content-type': 'application/json+cesr', accept: 'application/json' }, body: cesr
    }).then(response => ({ operation: 'PRESENT_CREDENTIAL',
      state: response.status === 202 ? 'ACCEPTED_FOR_ASYNC_PROCESSING' : 'NOT_ACCEPTED',
      httpStatus: response.status, said,
      next: response.status === 202 ? 'Poll /api/vlei/authorizations/{holderAID} and inspect its result.' :
        'Check CESR format, schema policy, and local verifier logs.',
      credentialVerified: false, holderAuthenticated: false, applicationAuthorizationGranted: false,
      checkedAt: new Date().toISOString() }));
  }
  function authorization(aid) {
    identifier(aid, 'Holder AID');
    return call('/authorizations/' + encodeURIComponent(aid), { headers: { accept: 'application/json' } })
      .then(response => response.text().then(value => {
        if (value.length > 32768) throw fail(502, 'Verifier response too large');
        let info = null;
        if (value) { try { info = JSON.parse(value); } catch (_) { /* Unexpected format, fail closed. */ } }
        // Require the verifier response to bind the expected holder AID to a credential SAID.
        // If its version returns a different JSON shape, adapt this mapping after inspection.
        const match = response.status === 200 && info && typeof info === 'object' &&
          info.aid === aid && typeof info.said === 'string' && IDENTIFIER.test(info.said);
        let state = 'UNEXPECTED_RESPONSE';
        if (response.status === 404) state = 'NOT_FOUND_OR_PENDING';
        else if (response.status === 401) state = 'REJECTED_BY_VERIFIER';
        else if (match) state = 'RECOGNISED_BY_CONFIGURED_VERIFIER';
        return { operation: 'CHECK_HOLDER_AUTHORIZATION', aid, state, httpStatus: response.status,
          credentialSaid: match ? info.said : null,
          verifierRecognised: !!match,
          holderAuthenticated: false, applicationAuthorizationGranted: false,
          trustConfigurationAttested: false,
          note: 'This is the local verifier response, not proof the browser operator controls this AID or may act for an organisation.',
          checkedAt: new Date().toISOString() };
      }));
  }
  return { configuration, present, authorization };
}
module.exports = { createVerifierBridge, identifier, verifierUrl };
